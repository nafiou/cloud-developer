App url end-point: http://image-filter-starter-code2-dev2.us-east-1.elasticbeanstalk.com/
Repository url: https://github.com/nafiou/cloud-developer/tree/master/course-02/project/image-filter-starter-code

